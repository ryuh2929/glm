"""Reproducible synthetic examples."""
